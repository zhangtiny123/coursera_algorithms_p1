import edu.princeton.cs.algs4.WeightedQuickUnionUF;
import edu.princeton.cs.algs4.StdRandom;

public class Percolation {
    private WeightedQuickUnionUF wuf;
    //sites state array, blocked: 0, opened: 1
    private int[] sitesState;
    private int openSitesCount;
    public int sitesLen;
    public int edgeSize;

    // create n-by-n grid, with all sites blocked
    public Percolation(int n) {
        if (n <= 0) {
            throw new IllegalArgumentException("n must greater than 0");
        }

        edgeSize = n;
        openSitesCount = 0;
        sitesLen = n * n + 2;
        wuf = new WeightedQuickUnionUF(sitesLen);

        sitesState = new int[sitesLen];
        
        // first and last are virtual sites.
        sitesState[0] = 1;
        sitesState[sitesLen - 1] = 1;
        for(int i = 1; i < sitesLen - 1; i++) {
            sitesState[i] = 0;
        }
    }

    private int getIndexOf(int row, int col) {
        return (row - 1) * edgeSize + col;
    }

    // open site (row, col) if it is not open already
    public void open(int row, int col) {
        if (row < 1 || row > edgeSize || col < 1 || col > edgeSize) {
            throw new IllegalArgumentException("row and col must between 1 to n");
        }

        int targetIndex = getIndexOf(row, col);
        if (sitesState[targetIndex] == 1) {
            return;
        }

        sitesState[targetIndex] = 1;
        openSitesCount++;
        int sitesLen = sitesState.length;

        int upTempIndex = targetIndex - edgeSize;
        int upIndex = upTempIndex > 0 ? upTempIndex : 0;
        int downTempIndex = targetIndex + edgeSize;
        int downIndex = downTempIndex < sitesLen - 1 ? downTempIndex : sitesLen - 1;
        int leftTempIndex = targetIndex - 1;
        int leftIndex = leftTempIndex % edgeSize == 0 ? -1 : leftTempIndex;
        int rightTempIndex = targetIndex + 1;
        int rightIndex = rightTempIndex % edgeSize == 1 ? -1 : rightTempIndex;

        if (sitesState[upIndex] == 1) {
            wuf.union(targetIndex, upIndex);
        }

        if (sitesState[downIndex] == 1) {
            wuf.union(targetIndex, downIndex);
        }

        if (leftIndex != -1) {
            if (sitesState[leftIndex] == 1) {
                wuf.union(targetIndex, leftIndex);
            }
        }

        if (rightIndex != -1) {
            if (sitesState[rightIndex] == 1) {
                wuf.union(targetIndex, rightIndex);
            }
        }
    }

    // is site (row, col) open?
    public boolean isOpen(int row, int col) {
        if (row < 1 || row > edgeSize || col < 1 || col > edgeSize) {
            throw new IllegalArgumentException("row and col must between 1 to n");
        }

        int index = getIndexOf(row, col);
        return sitesState[index] == 1;
    }

    // is site (row, col) full?
    public boolean isFull(int row, int col) {
        if (row < 1 || row > edgeSize || col < 1 || col > edgeSize) {
            throw new IllegalArgumentException("row and col must between 1 to n");
        }
        
        int index = getIndexOf(row, col);
        return wuf.connected(index, 0);

    }

    // number of open sites
    public int numberOfOpenSites() {
        return openSitesCount;
    }

    // does the system percolate?
    public boolean percolates() {
        return wuf.connected(sitesLen - 1, 0);
    }

    // test client (optional)
    public static void main(String[] args) {
        int eSize;
        if (args.length != 0) {
            eSize = Integer.parseInt(args[0]);
        } else {
            eSize = 100;
        }
        Percolation pTest = new Percolation(eSize);
        while (!pTest.percolates()) {
            int randRow = StdRandom.uniform(pTest.edgeSize) + 1;
            int randCol = StdRandom.uniform(pTest.edgeSize) + 1;
            pTest.open(randRow, randCol);
        }

        int openCount = pTest.numberOfOpenSites();
        System.out.println("Open sites number: " + openCount);
        int allCount = pTest.sitesLen - 2;
        System.out.println("Whole sites number: " + allCount);
        System.out.println("rate: " + ((double)openCount / (double)allCount));
    }
}